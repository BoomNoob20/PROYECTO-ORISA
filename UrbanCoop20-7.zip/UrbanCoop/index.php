<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Urban Coop - Cooperativas</title>
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* CSS Variables for Dark Mode */
        :root {
            --bg-color: #ffffff;
            --text-color: #333333;
            --card-bg: #ffffff;
            --border-color: #e0e0e0;
            --nav-bg: #ffffff;
            --footer-bg: #1a1a1a;
            --coop-bg: #f5f5f5;
            --news-bg: #ffffff;
            --testimonios-bg: #f8f9fa;
        }

        [data-theme="dark"] {
            --bg-color: #1a1a1a;
            --text-color: #ffffff;
            --card-bg: #2d2d2d;
            --border-color: #404040;
            --nav-bg: #2d2d2d;
            --footer-bg: #0d0d0d;
            --coop-bg: #2d2d2d;
            --news-bg: #1a1a1a;
            --testimonios-bg: #2d2d2d;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
        }

        /* Header Styles */
        .header {
            background: var(--nav-bg);
            padding: 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
            border-bottom: 1px solid var(--border-color);
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            height: 70px;
        }

        .logo {
            display: flex;
            align-items: center;
            font-size: 20px;
            font-weight: 700;
            color: var(--text-color);
            flex-shrink: 0;
            text-decoration: none;
        }

        .logo img {
            width: 120px;
            height: 60px;
            margin-right: 12px;
            border-radius: 6px;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 40px;
            align-items: center;
            margin: 0;
            padding: 0;
        }

        .nav-menu li {
            position: relative;
        }

        .nav-menu a {
            text-decoration: none;
            color: var(--text-color);
            font-size: 16px;
            font-weight: 500;
            transition: all 0.3s ease;
            padding: 8px 16px;
            border-radius: 6px;
            position: relative;
        }

        .nav-menu a:hover {
            color: #ff4444;
            background-color: rgba(255, 68, 68, 0.1);
        }

        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            width: 0;
            height: 2px;
            background: #ff4444;
            transition: all 0.3s ease;
            transform: translateX(-50%);
        }

        .nav-menu a:hover::after {
            width: 100%;
        }

        .nav-controls {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .dark-mode-toggle {
            background: none;
            border: 2px solid var(--border-color);
            cursor: pointer;
            padding: 10px;
            border-radius: 50%;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 44px;
            height: 44px;
        }

        .dark-mode-toggle:hover {
            background-color: var(--border-color);
            transform: scale(1.1);
        }

        .dark-mode-toggle svg {
            width: 20px;
            height: 20px;
            fill: var(--text-color);
            transition: all 0.3s ease;
        }

        .dark-mode-toggle.rotating {
            transform: rotate(180deg);
        }

        .login-btn {
            background: #ff4444 !important;
            color: white !important;
            padding: 12px 24px !important;
            border-radius: 25px !important;
            transition: all 0.3s ease !important;
            font-weight: 600 !important;
            font-size: 14px !important;
            border: none !important;
            cursor: pointer !important;
            text-decoration: none !important;
            display: inline-block !important;
        }

        .login-btn:hover {
            background: #e63939 !important;
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 15px rgba(255, 68, 68, 0.3) !important;
        }

        .login-btn::after {
            display: none !important;
        }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--text-color);
            padding: 5px;
        }

        /* Hero Section */
        .hero {
            position: relative;
            height: 100vh;
            overflow: hidden;
            background: #1a1a1a;
        }

        .video-container {
            position: relative;
            width: 100%;
            height: 100%;
        }

        .video-container video {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            transform: translate(-50%, -50%);
            z-index: 1;
        }

        .video-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.3);
            z-index: 2;
        }

        /* Cooperativas Section */
        .cooperativas {
            padding: 80px 0;
            background: var(--coop-bg);
            transition: background-color 0.3s ease;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .coop-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .coop-card {
            background: var(--card-bg);
            padding: 40px 30px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }

        .coop-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.15);
        }

        .coop-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ff4444, #e63939);
            margin: 0 auto 25px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 32px;
            box-shadow: 0 4px 15px rgba(255, 68, 68, 0.3);
        }

        .coop-type {
            color: #666;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 10px;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .coop-card h3 {
            color: var(--text-color);
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 700;
        }

        .coop-card p {
            color: #666;
            margin-bottom: 30px;
            font-size: 16px;
            line-height: 1.6;
        }

        .btn {
            background: #2c3e50;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #34495e;
            transform: translateY(-2px);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-container {
                padding: 10px 15px;
                height: 60px;
            }

            .logo {
                font-size: 18px;
            }

            .logo img {
                width: 32px;
                height: 32px;
            }

            .menu-toggle {
                display: block;
            }
            
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: var(--nav-bg);
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                flex-direction: column;
                padding: 20px;
                gap: 15px;
                border-top: 1px solid var(--border-color);
            }
            
            .nav-menu.active {
                display: flex;
            }

            .nav-controls {
                gap: 10px;
            }

            .dark-mode-toggle {
                width: 40px;
                height: 40px;
                padding: 8px;
            }

            .login-btn {
                padding: 10px 20px !important;
                font-size: 13px !important;
            }
        }

        /* Additional utility classes */
        .text-center {
            text-align: center;
        }

        .section-title {
            font-size: 36px;
            color: var(--text-color);
            margin-bottom: 15px;
            font-weight: 700;
        }

        .section-subtitle {
            color: #666;
            margin-bottom: 50px;
            font-size: 16px;
            line-height: 1.6;
        }

        /* Smooth scroll */
        html {
            scroll-behavior: smooth;
        }

        /* Animation keyframes */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }

        /* Additional sections styling */
        .novedades {
            padding: 80px 0;
            background: var(--news-bg);
            transition: background-color 0.3s ease;
        }

        .news-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 40px;
        }

        .news-item {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            padding: 20px;
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .news-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .news-image {
            width: 150px;
            height: 100px;
            border-radius: 8px;
            overflow: hidden;
            flex-shrink: 0;
        }

        .news-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .news-content h3 {
            color: var(--text-color);
            margin-bottom: 10px;
            font-size: 18px;
            font-weight: 600;
        }

        .news-content p {
            color: #666;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 10px;
        }

        .news-date {
            color: #999;
            font-size: 12px;
        }

        .proceso-section {
            padding: 80px 0;
            background: var(--bg-color);
        }

        .proceso-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .proceso-step {
            text-align: center;
            padding: 30px 20px;
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .proceso-step:hover {
            transform: translateY(-5px);
        }

        .paso-numero {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #ff4444, #e63939);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            margin: 0 auto 20px;
        }

        .proceso-step h3 {
            color: var(--text-color);
            margin-bottom: 15px;
            font-size: 20px;
            font-weight: 600;
        }

        .proceso-step p {
            color: #666;
            font-size: 14px;
            line-height: 1.6;
        }

        .testimonios {
            padding: 80px 0;
            background: var(--testimonios-bg);
        }

        .testimonios-title {
            text-align: center;
            font-size: 32px;
            color: var(--text-color);
            margin-bottom: 50px;
            font-weight: 700;
        }

        .testimonios-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .testimonio {
            text-align: center;
            padding: 30px;
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }

        .testimonio-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin: 0 auto 20px;
            object-fit: cover;
            border: 3px solid #ff4444;
        }

        .testimonio p {
            font-style: italic;
            color: #666;
            margin-bottom: 15px;
            font-size: 16px;
            line-height: 1.6;
        }

        .stars {
            color: #ffd700;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .stats-section {
            background: #2c3e50;
            padding: 80px 0;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            text-align: center;
        }

        .stat-item {
            color: white;
        }

        .stat-number {
            font-size: 48px;
            font-weight: bold;
            color: #ff4444;
            margin-bottom: 10px;
        }

        .stat-label {
            font-size: 18px;
            color: #bdc3c7;
        }

        .footer {
            background: var(--footer-bg);
            color: white;
            padding: 60px 0 20px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-section h3 {
            color: #ff4444;
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: 600;
        }

        .footer-section p {
            color: #bdc3c7;
            margin-bottom: 15px;
            font-size: 14px;
            line-height: 1.6;
        }

        .footer-section a {
            color: #bdc3c7;
            text-decoration: none;
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            transition: color 0.3s;
        }

        .footer-section a:hover {
            color: #ff4444;
        }

        .footer-logo {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .footer-logo-image {
            width: 40px;
            height: 40px;
            margin-right: 12px;
            border-radius: 6px;
        }

        .footer-bottom {
            text-align: center;
            padding: 20px 0;
            border-top: 1px solid #333;
            color: #bdc3c7;
        }

        .orisa-logo {
            color: #ff4444;
            font-weight: bold;
        }
    </style>
</head>
<body>
        
    <!-- Header -->
    <header class="header">
        <div class="nav-container">
            <div class="logo">
                <img src="IMG/result_descarga.png" alt="Logo" class="logo-image" id="logo-header">
            </div>
            <nav>
                <ul class="nav-menu">
                    <li><a href="#Inicio">Inicio</a></li>
                    <li><a href="#Novedades">Novedades</a></li>
                    <li><a href="#testimonios">Clientes</a></li>
                    <li><a href="#footer-content">Contacto</a></li>
                </ul>
                <button class="menu-toggle" id="menuToggle">≡ Menú</button>
            </nav>
            <div class="nav-controls">
                <button class="dark-mode-toggle" id="darkModeToggle">
                    <svg id="lightIcon" viewBox="0 0 24 24">
                        <path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM18.894 6.166a.75.75 0 00-1.06-1.06l-1.591 1.59a.75.75 0 101.06 1.061l1.591-1.59zM21.75 12a.75.75 0 01-.75.75h-2.25a.75.75 0 010-1.5H21a.75.75 0 01.75.75zM17.834 18.894a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 10-1.061 1.06l1.59 1.591zM12 18a.75.75 0 01.75.75V21a.75.75 0 01-1.5 0v-2.25A.75.75 0 0112 18zM7.758 17.303a.75.75 0 00-1.061-1.06l-1.591 1.59a.75.75 0 001.06 1.061l1.591-1.59zM6 12a.75.75 0 01-.75.75H3a.75.75 0 010-1.5h2.25A.75.75 0 016 12zM6.697 7.757a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 00-1.061 1.06l1.59 1.591z"/>
                    </svg>
                    <svg id="darkIcon" viewBox="0 0 24 24" style="display: none;">
                        <path d="M9.528 1.718a.75.75 0 01.162.819A8.97 8.97 0 009 6a9 9 0 009 9 8.97 8.97 0 003.463-.69.75.75 0 01.981.98 10.503 10.503 0 01-9.694 6.46c-5.799 0-10.5-4.701-10.5-10.5 0-4.368 2.667-8.112 6.46-9.694a.75.75 0 01.818.162z"/>
                    </svg>
                </button>
                <a href="loginLP.php    " class="login-btn">Iniciar Sesión</a>
            </div>
        </div>
    </header>

    <!-- Hero Section with Video -->
    <section id="Inicio" class="hero">
        <div class="video-container">
            <video autoplay muted loop>
                <source name="video-render" src="IMG/Untitled.mp4" type="video/mp4">
                Tu navegador no soporta el elemento video.
            </video>
            <div class="video-overlay"></div>
        </div>
    </section>

    <!-- Cooperativas Section -->
    <section class="cooperativas">
        <div class="container">
            <div class="coop-grid">
                <div class="coop-card">
                    <div class="coop-icon">🏠</div>
                    <div class="coop-type">COOPERATIVAS</div>
                    <h3>En formación y trámite</h3>
                    <p>Para saber más sobre estas cooperativas la visitamos a</p>
                    <a href="#" class="btn">Ver más</a>
                </div>
                <div class="coop-card">
                    <div class="coop-icon">🏠</div>
                    <div class="coop-type">COOPERATIVAS</div>
                    <h3>En obra</h3>
                    <p>Para saber más sobre estas cooperativas la visitamos a</p>
                    <a href="#" class="btn">Ver más</a>
                </div>
                <div class="coop-card">
                    <div class="coop-icon">🏠</div>
                    <div class="coop-type">COOPERATIVAS</div>
                    <h3>Habitadas</h3>
                    <p>Para saber más sobre estas cooperativas la visitamos a</p>
                    <a href="#" class="btn">Ver más</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Novedades Section -->
    <section id="Novedades" class="novedades">
        <div class="container">
            <h2 class="section-title">Novedades</h2>
            <p class="section-subtitle">En esta sección encontrarás las principales novedades relacionadas con el tema de cooperativas, acciones, publicaciones, plazas, convocatorias de vivienda, cooperativas, actividades de desarrollo, eventos importantes.</p>
            
            <div class="news-grid">
                <div class="news-column">
                    <div class="news-item">
                        <div class="news-image">
                            <img src="IMG/result_images.jpeg" alt="FUCVAM" class="news-img">
                        </div>
                        <div class="news-content">
                            <h3>Llamado laboral</h3>
                            <p>Llamado laboral de la Dirección Nacional de FUCVAM les ha efectuado un Trabajador Social para trabajar con la</p>
                            <div class="news-date">08 de enero del 2025</div>
                        </div>
                    </div>

                    <div class="news-item">
                        <div class="news-image">
                            <img src="IMG/result_20231227_05_1.jpg" alt="Congreso de Cooperativas" class="news-img">
                        </div>
                        <div class="news-content">
                            <h3>CONGRESO ANUAL DE COOPERATIVAS DE VIVIENDA</h3>
                            <p>CONVITES y la Federación a la Mesa "Quintañenas"</p>
                            <div class="news-date">15 de febrero del 2025</div>
                        </div>
                    </div>
                </div>

                <div class="news-column">
                    <div class="news-item">
                        <div class="news-image">
                            <img src="IMG/result_Proyecto Educativo.jpg" alt="Encuentro Nacional" class="news-img">
                        </div>
                        <div class="news-content">
                            <h3>ENCUENTRO NACIONAL HACIA UN FUTURO SOSTENIBLE</h3>
                            <p>Construyendo un presente, pasado y futuro rural para. Proyectos hacia para el desarrollo sostenible.</p>
                            <div class="news-date">También deberías saber algo con el desarrollo y el desarrollo económico desarrollo nacional breve como referencia a la fecha Hasta</div>
                        </div>
                    </div>

                    <div class="news-item">
                        <div class="news-image">
                            <img src="IMG/result_20250605-RVA-2334-2.jpg" alt="Obra Social" class="news-img">
                            <div class="news-overlay">INFORMES DE OBRA SOCIAL</div>
                        </div>
                        <div class="news-content">
                            <h3>Nuevo valor de cuota social</h3>
                            <p>A la fecha enero 2025</p>
                            <div class="news-date">18 de febrero del 2025</div>
                        </div>
                    </div>
                </div>
            </div>

            <div style="margin-top: 30px;">
                <div class="news-item">
                    <div class="news-image">
                        <img src="IMG/result_356d79_2790066112fd45c782e45cc5d95e6d88~mv2.jpg" alt="Proyecto Educativo" class="news-img">
                    </div>
                    <div class="news-content">
                        <h3>PROYECTO EDUCATIVO COMUNITARIO URUGUAY</h3>
                        <p>A-1-Sí Montevideo llevó a cabo el primer encuentro del proyecto "Cuadro de Mesa Sabiola"</p>
                        <p>Al-1-Sí Montevideo llevó a cabo el primer encuentro del proyecto educativo del Hábitat 2 de Convención, en el proyecto que...</p>
                        <div class="news-date">02 de febrero del 2025</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Proceso Section -->
    <section class="proceso-section">
        <div class="container">
            <h2 class="section-title">Proceso de Inscripción</h2>
            <p class="section-subtitle">Conoce los pasos para formar parte de una cooperativa de vivienda</p>
            
            <div class="proceso-grid">
                <div class="proceso-step">
                    <div class="paso-numero">1</div>
                    <h3>Información</h3>
                    <p>Infórmate sobre los requisitos y beneficios de pertenecer a una cooperativa de vivienda</p>
                </div>
                <div class="proceso-step">
                    <div class="paso-numero">2</div>
                    <h3>Inscripción</h3>
                    <p>Completa el formulario de inscripción y presenta la documentación requerida</p>
                </div>
                <div class="proceso-step">
                    <div class="paso-numero">3</div>
                    <h3>Evaluación</h3>
                    <p>Tu solicitud será evaluada por nuestro equipo técnico especializado</p>
                </div>
                <div class="proceso-step">
                    <div class="paso-numero">4</div>
                    <h3>Integración</h3>
                    <p>Una vez aprobada tu solicitud, formarás parte de la cooperativa</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonios Section -->
    <section id="testimonios" class="testimonios">
        <div class="container">
            <h2 class="testimonios-title">Lo que dicen nuestros cooperativistas</h2>
            
            <div class="testimonios-grid">
                <div class="testimonio">
                    <img src="IMG/descarga (1).png" alt="Martín Rodríguez" class="testimonio-avatar">
                    <p>"Gracias a Urban Coop pude acceder a mi vivienda propia. El proceso fue transparente y el acompañamiento excelente."</p>
                    <div class="stars">★★★★★</div>
                    <strong>Martín Rodríguez</strong>
                </div>
                <div class="testimonio">
                    <img src="IMG/wmremove-transformed.png" alt="Andrés Pereira" class="testimonio-avatar">
                    <p>"La experiencia cooperativa cambió mi vida. Ahora tengo mi hogar y formo parte de una comunidad solidaria."</p>
                    <div class="stars">★★★★</div>
                    <strong>Andrés Pereira</strong>
                </div>
                <div class="testimonio">
                    <img src="IMG/wmremove-transformed (2).png" alt="Lucía Fernández" class="testimonio-avatar">
                    <p>"Urban Coop me brindó la oportunidad de tener mi casa mediante el sistema cooperativo. Totalmente recomendable."</p>
                    <div class="stars">★★★★★</div>
                    <strong>Lucía Fernández</strong>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number">150+</div>
                    <div class="stat-label">Cooperativas Activas</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">2500+</div>
                    <div class="stat-label">Familias Beneficiadas</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">25</div>
                    <div class="stat-label">Años de Experiencia</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">98%</div>
                    <div class="stat-label">Satisfacción</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer id="footer-content" class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-logo">
                        <img src="UrbanCoop Black.jpeg" alt="" class="footer-logo-image">
                    </div>
                    <p>Facilitamos el acceso a la vivienda a través del sistema cooperativo, promoviendo la solidaridad y el desarrollo comunitario.</p>
                    <p>Tu hogar, nuestra misión.</p>
                </div>
                
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <a href="#cooperativas">Cooperativas</a>
                    <a href="#novedades">Novedades</a>
                    <a href="#proceso">Proceso</a>
                    <a href="#testimonios">Testimonios</a>
                    <a href="#contacto">Contacto</a>
                </div>
                
                <div class="footer-section">
                    <h3>Servicios</h3>
                    <a href="#">Cooperativas en Formación</a>
                    <a href="#">Cooperativas en Obra</a>
                    <a href="#">Cooperativas Habitadas</a>
                    <a href="#">Asesoramiento Legal</a>
                    <a href="#">Trabajo Social</a>
                </div>
                
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>📍 Av. 18 de Julio 1234, Montevideo</p>
                    <p>📞 (+598) 2901-1234</p>
                    <p>✉️ info@urbancoop.com.uy</p>
                    <p>🕒 Lunes a Viernes: 9:00 - 17:00</p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 Urban Coop. Todos los derechos reservados.</p>
                <p>Desarrollado por <span class="orisa-logo">ORISA</span></p>
            </div>
        </div>
    </footer>

    <script>

const darkModeToggle = document.getElementById('darkModeToggle');
const lightIcon = document.getElementById('lightIcon');
const darkIcon = document.getElementById('darkIcon');
const body = document.body;
const logo = document.getElementById('logo-header'); 


const currentTheme = localStorage.getItem('theme') || 'light';
body.setAttribute('data-theme', currentTheme);


if (currentTheme === 'dark') {
    lightIcon.style.display = 'none';
    darkIcon.style.display = 'block';
    if (logo) logo.src = 'IMG/result_UrbanCoop White.jpeg';
} else {
    if (logo) logo.src = 'IMG/result_descarga.png';
}

darkModeToggle.addEventListener('click', () => {
    const currentTheme = body.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

    body.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);

    location.reload();
});


const menuToggle = document.getElementById('menuToggle');
const navMenu = document.querySelector('.nav-menu');

menuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
});

document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
    });
});

const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in-up');
        }
    });
}, observerOptions);


document.querySelectorAll('.coop-card, .news-item, .proceso-step, .testimonio, .stat-item').forEach(el => {
    observer.observe(el);
});


document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
    </script>

</body>
</html>