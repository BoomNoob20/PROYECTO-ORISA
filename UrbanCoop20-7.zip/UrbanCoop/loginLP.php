<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - Elegant Theme Toggle</title>
    <style>
        :root {
            --bg-color: #f5f5f5;
            --container-bg: white;
            --text-color: #1a1a1a;
            --text-secondary: #666;
            --input-bg: #f8f8f8;
            --input-border: #e0e0e0;
            --input-text: #1a1a1a;
            --input-placeholder: #999;
            --social-border: #333;
            --social-text: #333;
            --primary-color: #ff4444;
            --primary-hover: #e03e3e;
            --shadow: rgba(0, 0, 0, 0.1);
            --toggle-bg: #ffffff;
            --toggle-border: #e5e7eb;
            --toggle-icon: #374151;
        }

        [data-theme="dark"] {
            --bg-color: #121212;
            --container-bg: #1e1e1e;
            --text-color: #ffffff;
            --text-secondary: #b3b3b3;
            --input-bg: #2a2a2a;
            --input-border: #404040;
            --input-text: #ffffff;
            --input-placeholder: #888;
            --social-border: #666;
            --social-text: #ffffff;
            --primary-color: #ff4444;
            --primary-hover: #e03e3e;
            --shadow: rgba(0, 0, 0, 0.3);
            --toggle-bg: #374151;
            --toggle-border: #4b5563;
            --toggle-icon: #f9fafb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            transition: background-color 0.3s ease;
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            background-color: var(--toggle-bg);
            border: 1px solid var(--toggle-border);
            border-radius: 50%;
            width: 48px;
            height: 48px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .theme-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        .theme-toggle:active {
            transform: scale(0.95);
        }

        .toggle-icon {
            color: var(--toggle-icon);
            font-size: 20px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sun-icon, .moon-icon {
            position: absolute;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .sun-icon {
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }

        .moon-icon {
            opacity: 0;
            transform: rotate(-90deg) scale(0.5);
        }

        [data-theme="dark"] .sun-icon {
            opacity: 0;
            transform: rotate(90deg) scale(0.5);
        }

        [data-theme="dark"] .moon-icon {
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }

        .login-container {
            display: flex;
            background-color: var(--container-bg);
            border-radius: 20px;
            box-shadow: 0 20px 40px var(--shadow);
            overflow: hidden;
            max-width: 800px;
            width: 100%;
            min-height: 500px;
            transition: all 0.3s ease;
        }

        .login-form {
            flex: 1;
            padding: 60px 50px;
            background-color: var(--container-bg);
            display: flex;
            flex-direction: column;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .login-form h1 {
            color: var(--text-color);
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 40px;
            transition: color 0.3s ease;
        }

        .social-login {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
        }

        .social-btn {
            width: 50px;
            height: 50px;
            border: 2px solid var(--social-border);
            background-color: var(--container-bg);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: bold;
            color: var(--social-text);
        }

        .social-btn:hover {
            background-color: var(--social-border);
            color: var(--container-bg);
            transform: translateY(-2px);
        }

        .divider {
            text-align: center;
            margin: 30px 0;
            color: var(--text-secondary);
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-input {
            width: 100%;
            padding: 18px 20px;
            border: 2px solid var(--input-border);
            border-radius: 12px;
            font-size: 1rem;
            background-color: var(--input-bg);
            transition: all 0.3s ease;
            color: var(--input-text);
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-color);
            background-color: var(--container-bg);
            box-shadow: 0 0 0 3px rgba(255, 68, 68, 0.1);
        }

        .form-input::placeholder {
            color: var(--input-placeholder);
        }

        .forgot-password {
            text-align: center;
            margin: 20px 0;
        }

        .forgot-password a {
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .forgot-password a:hover {
            color: var(--primary-color);
        }

        .submit-btn {
            text-align: center;
            margin: 20px 0;
        }

        .login-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 18px 40px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .login-btn:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 68, 68, 0.3);
        }

        .welcome-section {
            flex: 1;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-hover) 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 60px 40px;
            color: white;
        }

        .welcome-section h2 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .welcome-section p {
            font-size: 1.1rem;
            margin-bottom: 40px;
            opacity: 0.9;
            line-height: 1.5;
        }

        .signup-btn {
            background-color: transparent;
            color: white;
            border: 2px solid white;
            padding: 15px 35px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-decoration: none;
            display: inline-block;
        }

        .signup-btn:hover {
            background-color: white;
            color: var(--primary-color);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 255, 255, 0.2);
        }

        @media (max-width: 768px) {
            .theme-toggle {
                top: 15px;
                right: 15px;
                width: 42px;
                height: 42px;
            }

            .toggle-icon {
                font-size: 18px;
            }

            .login-container {
                flex-direction: column;
                max-width: 400px;
            }

            .login-form, .welcome-section {
                padding: 40px 30px;
            }

            .login-form h1, .welcome-section h2 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="theme-toggle" id="themeToggle">
        <div class="toggle-icon">
            <span class="sun-icon">☀</span>
            <span class="moon-icon">🌙</span>
        </div>
    </div>

    <div class="login-container">
        <div class="login-form">
            <h1>Sign in</h1>
    
            <form id="loginForm" method="post" action="http://localhost/URBANCOOP/API_Usuarios.php/login">
                <div class="form-group">
                    <input name="email" type="email" class="form-input" placeholder="Email" required>
                </div>
                
                <div class="form-group">
                    <input name="password" type="password" class="form-input" placeholder="Password" required>
                </div>
                
                <div class="forgot-password">
                    <a href="#">Forgot your password?</a>
                </div>
                <div class="submit-btn">
                    <button type="submit" class="login-btn">SIGN IN</button>
                </div>

            </form>
        </div>
        
        <div class="welcome-section">
            <h2>Welcome Back!</h2>
            <p>To keep connected with us please login with your personal info</p>
            <a href="registerLP.php" class="signup-btn">SIGN UP</a>
        </div>
    </div>

    <script>
        // Theme toggle functionality
        const themeToggle = document.getElementById('themeToggle');
        const body = document.body;
        const sunIcon = document.querySelector('.sun-icon');
        const moonIcon = document.querySelector('.moon-icon');

        // Get saved theme from memory (since we can't use localStorage in artifacts)
        let currentTheme = 'light';

        // Function to toggle theme
        function toggleTheme() {
            currentTheme = currentTheme === 'light' ? 'dark' : 'light';
            body.setAttribute('data-theme', currentTheme);
        }

        themeToggle.addEventListener('click', toggleTheme);

        // Form functionality
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const form = e.target;
            const data = {
                email: form.email.value,
                password: form.password.value
            };
            fetch('http://localhost/URBANCOOP/API_Usuarios.php/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log(data["user"]["is_admin"]);
                    if (data["user"]["is_admin"] == 0) {
                        document.location = "perfil.php";
                    } else {
                        document.location = "admin.php";
                    }
                } else {
                    alert('Error al iniciar sesión: ' + data.message);
                }
            })
            .catch(error => {
                alert('Error al iniciar sesión');
                console.error(error);
            });
        });
    </script>
</body>
</html>