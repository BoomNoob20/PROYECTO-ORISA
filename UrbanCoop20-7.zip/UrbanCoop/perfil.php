<?php
session_start();

// Configuración de base de datos
$host = 'localhost';
$dbname = 'usuarios_urban_coop';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Para pruebas, si no hay session user_id, usar ID de prueba
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; // ID de usuario de prueba
}

// Obtener información del usuario
$stmt = $pdo->prepare("SELECT usr_name, usr_surname, estado FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Si no se encuentra el usuario, crear valores por defecto para pruebas
if (!$user) {
    $user = [
        'usr_name' => 'Usuario',
        'usr_surname' => 'Prueba',
        'estado' => 2
    ];
}

$user_name = $user['usr_name'] . ' ' . $user['usr_surname'];
$user_status = $user['estado'];

// Manejar diferentes estados del usuario
$status_message = '';
$can_access = false;

switch ($user_status) {
    case 1:
        $status_message = 'Esperando la aprobación manual de un administrador';
        $can_access = false;
        break;
    case 2:
        $can_access = true;
        break;
    case 3:
        $status_message = 'Usuario rechazado. Contacte con el administrador.';
        $can_access = false;
        break;
    default:
        $status_message = 'Estado de usuario desconocido';
        $can_access = false;
}

// Procesar formularios si el usuario está aprobado
if ($can_access && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'upload_payment':
                // Lógica para subir comprobante de pago
                if (isset($_FILES['payment_file'])) {
                    $target_dir = "uploads/payments/";
                    if (!file_exists($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    $target_file = $target_dir . $_SESSION['user_id'] . "_" . time() . "_" . basename($_FILES['payment_file']['name']);
                    
                    if (move_uploaded_file($_FILES['payment_file']['tmp_name'], $target_file)) {
                        $success_message = "Comprobante de pago subido exitosamente.";
                    } else {
                        $error_message = "Error al subir el archivo.";
                    }
                }
                break;
                
            case 'register_hours':
                // Lógica para registrar horas
                if (isset($_POST['work_date']) && isset($_POST['hours_worked'])) {
                    $work_date = $_POST['work_date'];
                    $hours_worked = $_POST['hours_worked'];
                    $description = $_POST['description'] ?? '';
                    
                    // Aquí insertarías en una tabla de horas trabajadas
                    $success_message = "Horas registradas exitosamente.";
                }
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Urban Coop - Dashboard</title>
    <link rel="stylesheet" href="perfil_styles.css">
</head>
<body>
    <?php if (!$can_access): ?>
    <!-- Estado de espera o rechazo -->
    <div style="display: flex; align-items: center; justify-content: center; height: 100vh; text-align: center;">
        <div style="background: white; padding: 40px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            <div style="font-size: 64px; margin-bottom: 20px;">
                <?php if ($user_status == 1): ?>
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ffa726" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12,6 12,12 16,14"></polyline>
                    </svg>
                <?php else: ?>
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#f44336" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="15" y1="9" x2="9" y2="15"></line>
                        <line x1="9" y1="9" x2="15" y2="15"></line>
                    </svg>
                <?php endif; ?>
            </div>
            <h2><?php echo $user_status == 1 ? 'Cuenta en Espera' : 'Cuenta Rechazada'; ?></h2>
            <p style="color: #666; margin-top: 10px;"><?php echo htmlspecialchars($status_message); ?></p>
        </div>
    </div>
    
    <?php else: ?>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <img src="IMG/UrbanCoop White.jpeg" alt="Urban Coop" class="logo-img">
                        
                </div>
                <div class="search-box">
                    <input type="text" class="search-input" placeholder="Buscar...">
                    <span class="search-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"></circle>
                            <path d="m21 21-4.35-4.35"></path>
                        </svg>
                    </span>
                </div>
            </div>
            
            <div class="menu-list">
                <div class="menu-item active">
                    <span class="menu-item-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="5"></circle>
                            <line x1="12" y1="1" x2="12" y2="3"></line>
                            <line x1="12" y1="21" x2="12" y2="23"></line>
                            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                            <line x1="1" y1="12" x2="3" y2="12"></line>
                            <line x1="21" y1="12" x2="23" y2="12"></line>
                            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                        </svg>
                    </span>
                    <span class="menu-item-text">Mi Día</span>
                    <span class="menu-item-count" id="myDayCount">0</span>
                </div>
                
                <div class="menu-item">
                    <span class="menu-item-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"></polygon>
                        </svg>
                    </span>
                    <span class="menu-item-text">Importantes</span>
                    <span class="menu-item-count">0</span>
                </div>
                
                <div class="menu-item">
                    <span class="menu-item-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M9 11H5a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h4m6-6h4a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-4m-6-6V9a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                    </span>
                    <span class="menu-item-text">Tareas</span>
                    <span class="menu-item-count">0</span>
                </div>
                
                <div class="menu-item">
                    <span class="menu-item-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                            <line x1="8" y1="21" x2="16" y2="21"></line>
                            <line x1="12" y1="17" x2="12" y2="21"></line>
                        </svg>
                    </span>
                    <span class="menu-item-text">Trabajo</span>
                    <span class="menu-item-count">15</span>
                </div>
                
                <div class="menu-item">
                    <span class="menu-item-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <polyline points="9,22 9,12 15,12 15,22"></polyline>
                        </svg>
                    </span>
                    <span class="menu-item-text">Casa</span>
                    <span class="menu-item-count">3</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="header-left">
                    <nav class="header-nav">
                        <button class="nav-btn active" onclick="showSection('tasks')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M9 11H5a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h4m6-6h4a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-4m-6-6V9a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                            Tareas
                        </button>
                        <button class="nav-btn" onclick="showSection('payments')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14,2 14,8 20,8"></polyline>
                                <line x1="16" y1="13" x2="8" y2="13"></line>
                                <line x1="16" y1="17" x2="8" y2="17"></line>
                                <polyline points="10,9 9,9 8,9"></polyline>
                            </svg>
                            Comprobantes
                        </button>
                        <button class="nav-btn" onclick="showSection('hours')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12,6 12,12 16,14"></polyline>
                            </svg>
                            Horas Trabajadas
                        </button>
                        <button class="nav-btn" onclick="showSection('payroll')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                                <line x1="1" y1="10" x2="23" y2="10"></line>
                            </svg>
                            Recibos de Sueldo
                        </button>
                    </nav>
                </div>
                
                <div class="header-right">
                    <div class="profile-menu">
                        <button class="profile-btn" onclick="toggleProfileMenu()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                            <?php echo htmlspecialchars($user_name); ?>
                        </button>
                        <div class="profile-dropdown" id="profileDropdown">
                            <a href="index.php">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Content Sections -->
            <div class="content-area">
                <!-- Tasks Section -->
                <div id="tasks-section" class="section active">
                    <div class="section-header">
                        <h2 class="section-title">Mis Tareas</h2>
                        <button class="add-btn" onclick="addNewTask()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                            </svg>
                            Agregar tarea
                        </button>
                    </div>
                    
                    <div class="task-list" id="taskList">
                        <div class="task-item">
                            <input type="checkbox" class="task-checkbox" onchange="toggleTask(this)">
                            <span class="task-text">Subir comprobante de pago mensual</span>
                        </div>
                        
                        <div class="task-item">
                            <input type="checkbox" class="task-checkbox" onchange="toggleTask(this)">
                            <span class="task-text">Completar registro de horas</span>
                        </div>
                        
                        <div class="task-item">
                            <input type="checkbox" class="task-checkbox" onchange="toggleTask(this)">
                            <span class="task-text">Revisar liquidación</span>
                        </div>
                        
                        <div class="task-item">
                            <input type="checkbox" class="task-checkbox" onchange="toggleTask(this)">
                            <span class="task-text">Actualizar datos personales</span>
                        </div>
                        
                        <div class="task-item">
                            <input type="checkbox" class="task-checkbox" onchange="toggleTask(this)">
                            <span class="task-text">Programar reunión equipo</span>
                        </div>
                    </div>
                </div>

                <!-- Payments Section -->
                <div id="payments-section" class="section">
                    <div class="section-header">
                        <h2 class="section-title">Comprobantes de Pago</h2>
                        <button class="add-btn" onclick="showUploadForm()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                <polyline points="7,10 12,15 17,10"></polyline>
                                <line x1="12" y1="15" x2="12" y2="3"></line>
                            </svg>
                            Subir Comprobante
                        </button>
                    </div>

                    <div id="upload-form" style="display: none;">
                        <div class="form-container">
                            <?php if (isset($success_message)): ?>
                                <div class="alert alert-success"><?php echo $success_message; ?></div>
                            <?php endif; ?>
                            
                            <?php if (isset($error_message)): ?>
                                <div class="alert alert-error"><?php echo $error_message; ?></div>
                            <?php endif; ?>
                            
                            <form method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="action" value="upload_payment">
                                
                                <div class="upload-area" id="uploadArea">
                                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                        <polyline points="7,10 12,15 17,10"></polyline>
                                        <line x1="12" y1="15" x2="12" y2="3"></line>
                                    </svg>
                                    <p>Arrastra y suelta tu archivo aquí o haz clic para seleccionar</p>
                                    <p style="font-size: 12px; color: #666; margin-top: 5px;">PDF, JPG, PNG - Máximo 5MB</p>
                                    <input type="file" name="payment_file" accept=".pdf,.jpg,.jpeg,.png" required>
                                </div>
                                
                                <div class="form-row">
                                    <div class="form-group" style="flex: 1;">
                                        <label>Mes de Pago</label>
                                        <select name="payment_month" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                                            <option value="">Seleccionar mes</option>
                                            <option value="01">Enero</option>
                                            <option value="02">Febrero</option>
                                            <option value="03">Marzo</option>
                                            <option value="04">Abril</option>
                                            <option value="05">Mayo</option>
                                            <option value="06">Junio</option>
                                            <option value="07">Julio</option>
                                            <option value="08">Agosto</option>
                                            <option value="09">Septiembre</option>
                                            <option value="10">Octubre</option>
                                            <option value="11">Noviembre</option>
                                            <option value="12">Diciembre</option>
                                        </select>
                                    </div>
                                    <div class="form-group" style="flex: 1;">
                                        <label>Año</label>
                                        <select name="payment_year" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                                            <option value="">Seleccionar año</option>
                                            <option value="2024">2024</option>
                                            <option value="2025">2025</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Descripción (opcional)</label>
                                    <textarea name="payment_description" rows="3" placeholder="Agregar notas adicionales..."></textarea>
                                </div>
                                
                                <div style="display: flex; gap: 10px;">
                                    <button type="submit" class="submit-btn">Subir Comprobante</button>
                                    <button type="button" class="submit-btn" onclick="hideUploadForm()" style="background: #666;">Cancelar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="file-list">
                        <div class="file-item">
                            <div class="file-info">
                                <h3>Comprobante Enero 2025</h3>
                                <p>Subido el 15 de enero, 2025 • PDF • 1.2 MB</p>
                            </div>
                            <button class="action-btn">Descargar</button>
                        </div>
                        
                        <div class="file-item">
                            <div class="file-info">
                                <h3>Comprobante Diciembre 2024</h3>
                                <p>Subido el 20 de diciembre, 2024 • PDF • 985 KB</p>
                            </div>
                            <button class="action-btn">Descargar</button>
                        </div>
                        
                        <div class="file-item">
                            <div class="file-info">
                                <h3>Comprobante Noviembre 2024</h3>
                                <p>Subido el 18 de noviembre, 2024 • PDF • 1.1 MB</p>
                            </div>
                            <button class="action-btn">Descargar</button>
                        </div>
                    </div>
                </div>

                <!-- Hours Section -->
                <div id="hours-section" class="section">
                    <div class="section-header">
                        <h2 class="section-title">Registro de Horas</h2>
                        <button class="add-btn" onclick="showHoursForm()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                            </svg>
                            Registrar Horas
                        </button>
                    </div>

                    <div id="hours-form" style="display: none;">
                        <div class="form-container">
                            <form method="POST">
                                <input type="hidden" name="action" value="register_hours">
                                
                                <div class="form-row">
                                    <div class="form-group" style="flex: 1;">
                                        <label>Fecha de Trabajo</label>
                                        <input type="date" name="work_date" required>
                                    </div>
                                    <div class="form-group" style="flex: 1;">
                                        <label>Horas Trabajadas</label>
                                        <input type="number" name="hours_worked" min="0" max="24" step="0.5" placeholder="8.0" required>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Descripción del Trabajo</label>
                                    <textarea name="description" rows="4" placeholder="Describe las actividades realizadas..." required></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <label>Tipo de Trabajo</label>
                                    <select name="work_type" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                                        <option value="">Seleccionar tipo</option>
                                        <option value="desarrollo">Desarrollo</option>
                                        <option value="reunion">Reuniones</option>
                                        <option value="documentacion">Documentación</option>
                                        <option value="testing">Testing</option>
                                        <option value="administrativo">Administrativo</option>
                                        <option value="otros">Otros</option>
                                    </select>
                                </div>
                                
                                <div style="display: flex; gap: 10px;">
                                    <button type="submit" class="submit-btn">Registrar Horas</button>
                                    <button type="button" class="submit-btn" onclick="hideHoursForm()" style="background: #666;">Cancelar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="hours-list">
                        <div class="hours-item">
                            <div class="hours-info">
                                <h3>21 de Julio, 2025 - 8 horas</h3>
                                <p>Desarrollo de nuevas funcionalidades • Desarrollo</p>
                            </div>
                            <button class="action-btn">Editar</button>
                        </div>
                        
                        <div class="hours-item">
                            <div class="hours-info">
                                <h3>20 de Julio, 2025 - 6 horas</h3>
                                <p>Reunión de equipo y planificación • Reuniones</p>
                            </div>
                            <button class="action-btn">Editar</button>
                        </div>
                        
                        <div class="hours-item">
                            <div class="hours-info">
                                <h3>19 de Julio, 2025 - 7.5 horas</h3>
                                <p>Testing y corrección de errores • Testing</p>
                            </div>
                            <button class="action-btn">Editar</button>
                        </div>
                        
                        <div class="hours-item">
                            <div class="hours-info">
                                <h3>18 de Julio, 2025 - 8 horas</h3>
                                <p>Documentación técnica del proyecto • Documentación</p>
                            </div>
                            <button class="action-btn">Editar</button>
                        </div>
                    </div>
                </div>

                <!-- Payroll Section -->
                <div id="payroll-section" class="section">
                    <div class="section-header">
                        <h2 class="section-title">Recibos de Sueldo</h2>
                    </div>
                    
                    <div class="payroll-list">
                        <div class="payroll-item">
                            <div class="payroll-info">
                                <h3>Recibo de Sueldo - Enero 2025</h3>
                                <p>Período: 01/01/2025 - 31/01/2025 • Generado el 05/02/2025</p>
                                <p><strong>Monto Bruto:</strong> $45,000 • <strong>Monto Neto:</strong> $35,500</p>
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button class="action-btn">Ver</button>
                                <button class="action-btn">Descargar</button>
                            </div>
                        </div>
                        
                        <div class="payroll-item">
                            <div class="payroll-info">
                                <h3>Recibo de Sueldo - Diciembre 2024</h3>
                                <p>Período: 01/12/2024 - 31/12/2024 • Generado el 05/01/2025</p>
                                <p><strong>Monto Bruto:</strong> $48,000 • <strong>Monto Neto:</strong> $37,200</p>
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button class="action-btn">Ver</button>
                                <button class="action-btn">Descargar</button>
                            </div>
                        </div>
                        
                        <div class="payroll-item">
                            <div class="payroll-info">
                                <h3>Recibo de Sueldo - Noviembre 2024</h3>
                                <p>Período: 01/11/2024 - 30/11/2024 • Generado el 05/12/2024</p>
                                <p><strong>Monto Bruto:</strong> $46,500 • <strong>Monto Neto:</strong> $36,200</p>
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button class="action-btn">Ver</button>
                                <button class="action-btn">Descargar</button>
                            </div>
                        </div>
                        
                        <div class="payroll-item">
                            <div class="payroll-info">
                                <h3>Recibo de Sueldo - Octubre 2024</h3>
                                <p>Período: 01/10/2024 - 31/10/2024 • Generado el 05/11/2024</p>
                                <p><strong>Monto Bruto:</strong> $44,000 • <strong>Monto Neto:</strong> $34,800</p>
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button class="action-btn">Ver</button>
                                <button class="action-btn">Descargar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script>
        // Navigation Functions
        function showSection(sectionName) {
            // Hide all sections
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Remove active class from all nav buttons
            document.querySelectorAll('.nav-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected section
            document.getElementById(sectionName + '-section').classList.add('active');
            
            // Add active class to clicked button
            event.target.closest('.nav-btn').classList.add('active');
        }

        // Profile Menu Toggle
        function toggleProfileMenu() {
            const dropdown = document.getElementById('profileDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const profileMenu = document.querySelector('.profile-menu');
            if (!profileMenu.contains(event.target)) {
                document.getElementById('profileDropdown').classList.remove('show');
            }
        });

        // Task Functions
        function toggleTask(checkbox) {
            const taskItem = checkbox.closest('.task-item');
            if (checkbox.checked) {
                taskItem.classList.add('completed');
            } else {
                taskItem.classList.remove('completed');
            }
            updateTaskCount();
        }

        function addNewTask() {
            const taskText = prompt('Ingresa el texto de la nueva tarea:');
            if (taskText && taskText.trim()) {
                const taskList = document.getElementById('taskList');
                const newTask = document.createElement('div');
                newTask.className = 'task-item';
                newTask.innerHTML = `
                    <input type="checkbox" class="task-checkbox" onchange="toggleTask(this)">
                    <span class="task-text">${taskText.trim()}</span>
                `;
                taskList.appendChild(newTask);
                updateTaskCount();
            }
        }

        function updateTaskCount() {
            const totalTasks = document.querySelectorAll('.task-item').length;
            const completedTasks = document.querySelectorAll('.task-item.completed').length;
            const remainingTasks = totalTasks - completedTasks;
            
            document.getElementById('myDayCount').textContent = remainingTasks;
        }

        // Form Functions
        function showUploadForm() {
            document.getElementById('upload-form').style.display = 'block';
        }

        function hideUploadForm() {
            document.getElementById('upload-form').style.display = 'none';
        }

        function showHoursForm() {
            document.getElementById('hours-form').style.display = 'block';
        }

        function hideHoursForm() {
            document.getElementById('hours-form').style.display = 'none';
        }

        // File Upload Drag & Drop
        const uploadArea = document.getElementById('uploadArea');
        if (uploadArea) {
            uploadArea.addEventListener('click', function() {
                this.querySelector('input[type="file"]').click();
            });

            uploadArea.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.style.borderColor = '#d32f2f';
                this.style.backgroundColor = '#fafafa';
            });

            uploadArea.addEventListener('dragleave', function(e) {
                e.preventDefault();
                this.style.borderColor = '#ddd';
                this.style.backgroundColor = 'white';
            });

            uploadArea.addEventListener('drop', function(e) {
                e.preventDefault();
                this.style.borderColor = '#ddd';
                this.style.backgroundColor = 'white';
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    this.querySelector('input[type="file"]').files = files;
                    this.querySelector('p').textContent = files[0].name;
                }
            });
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            updateTaskCount();
        });
    </script>
</body>
</html>