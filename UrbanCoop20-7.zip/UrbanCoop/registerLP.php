<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Elegant Theme Toggle</title>
    <style>
        :root {
            --bg-color: #f5f5f5;
            --container-bg: white;
            --text-color: #1a1a1a;
            --text-secondary: #666;
            --input-bg: #f8f8f8;
            --input-border: #e0e0e0;
            --input-text: #1a1a1a;
            --input-placeholder: #999;
            --social-border: #333;
            --social-text: #333;
            --primary-color: #ff4444;
            --primary-hover: #e03e3e;
            --error-bg: #f8d7da;
            --error-text: #721c24;
            --error-border: #f5c6cb;
            --success-bg: #d4edda;
            --success-text: #155724;
            --success-border: #c3e6cb;
            --shadow: rgba(0, 0, 0, 0.1);
            --toggle-bg: #ffffff;
            --toggle-border: #e5e7eb;
            --toggle-icon: #374151;
        }

        [data-theme="dark"] {
            --bg-color: #121212;
            --container-bg: #1e1e1e;
            --text-color: #ffffff;
            --text-secondary: #b3b3b3;
            --input-bg: #2a2a2a;
            --input-border: #404040;
            --input-text: #ffffff;
            --input-placeholder: #888;
            --social-border: #666;
            --social-text: #ffffff;
            --primary-color: #ff4444;
            --primary-hover: #e03e3e;
            --error-bg: #3d1a1a;
            --error-text: #ffb3b3;
            --error-border: #5c2626;
            --success-bg: #1a3d1a;
            --success-text: #b3ffb3;
            --success-border: #265c26;
            --shadow: rgba(0, 0, 0, 0.3);
            --toggle-bg: #374151;
            --toggle-border: #4b5563;
            --toggle-icon: #f9fafb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            transition: background-color 0.3s ease;
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            background-color: var(--toggle-bg);
            border: 1px solid var(--toggle-border);
            border-radius: 50%;
            width: 48px;
            height: 48px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .theme-toggle:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        .theme-toggle:active {
            transform: scale(0.95);
        }

        .toggle-icon {
            color: var(--toggle-icon);
            font-size: 20px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sun-icon, .moon-icon {
            position: absolute;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .sun-icon {
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }

        .moon-icon {
            opacity: 0;
            transform: rotate(-90deg) scale(0.5);
        }

        [data-theme="dark"] .sun-icon {
            opacity: 0;
            transform: rotate(90deg) scale(0.5);
        }

        [data-theme="dark"] .moon-icon {
            opacity: 1;
            transform: rotate(0deg) scale(1);
        }

        .login-container {
            display: flex;
            background-color: var(--container-bg);
            border-radius: 20px;
            box-shadow: 0 20px 40px var(--shadow);
            overflow: hidden;
            max-width: 800px;
            width: 100%;
            min-height: 500px;
            flex-direction: row-reverse;
            transition: all 0.3s ease;
        }

        .signup-form {
            flex: 1;
            padding: 40px 50px;
            background-color: var(--container-bg);
            display: flex;
            flex-direction: column;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .signup-form h1 {
            color: var(--text-color);
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 30px;
            transition: color 0.3s ease;
        }

        .social-login {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
        }

        .social-btn {
            width: 50px;
            height: 50px;
            border: 2px solid var(--social-border);
            background-color: var(--container-bg);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: bold;
            color: var(--social-text);
        }

        .social-btn:hover {
            background-color: var(--social-border);
            color: var(--container-bg);
            transform: translateY(-2px);
        }

        .divider {
            text-align: center;
            margin: 25px 0;
            color: var(--text-secondary);
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-input {
            width: 100%;
            padding: 15px 18px;
            border: 2px solid var(--input-border);
            border-radius: 12px;
            font-size: 1rem;
            background-color: var(--input-bg);
            transition: all 0.3s ease;
            color: var(--input-text);
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-color);
            background-color: var(--container-bg);
            box-shadow: 0 0 0 3px rgba(255, 68, 68, 0.1);
        }

        .form-input::placeholder {
            color: var(--input-placeholder);
        }

        .form-input.error {
            border-color: var(--primary-color);
            background-color: var(--error-bg);
        }

        .signup-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 18px 40px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 10px;
        }

        .signup-btn:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 68, 68, 0.3);
        }

        .signup-btn:disabled {
            background-color: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .welcome-section {
            flex: 1;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-hover) 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 60px 40px;
            color: white;
        }

        .welcome-section h2 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .welcome-section p {
            font-size: 1.1rem;
            margin-bottom: 40px;
            opacity: 0.9;
            line-height: 1.5;
        }

        .signin-btn {
            background-color: transparent;
            color: white;
            border: 2px solid white;
            padding: 15px 35px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-decoration: none;
            display: inline-block;
        }

        .signin-btn:hover {
            background-color: white;
            color: var(--primary-color);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 255, 255, 0.2);
        }

        .message {
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 0.9rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .message.success {
            background-color: var(--success-bg);
            color: var(--success-text);
            border: 1px solid var(--success-border);
        }

        .message.error {
            background-color: var(--error-bg);
            color: var(--error-text);
            border: 1px solid var(--error-border);
        }

        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #ffffff;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .theme-toggle {
                top: 15px;
                right: 15px;
                width: 42px;
                height: 42px;
            }

            .toggle-icon {
                font-size: 18px;
            }

            .login-container {
                flex-direction: column;
                max-width: 400px;
            }

            .signup-form, .welcome-section {
                padding: 40px 30px;
            }

            .signup-form h1, .welcome-section h2 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="theme-toggle" id="themeToggle">
        <div class="toggle-icon">
            <span class="sun-icon">☀</span>
            <span class="moon-icon">🌙</span>
        </div>
    </div>

    <div class="login-container">
        <div class="signup-form">
            <h1>Create Account</h1>
            
            <div id="message-container"></div>
            
            <form id="registerForm" action="API_Usuarios.php/register" method="POST">
                <div class="form-group">
                    <input type="text" name="name" id="name" class="form-input" placeholder="Name" required>
                </div>
                
                <div class="form-group">
                    <input type="text" name="surname" id="surname" class="form-input" placeholder="Surname" required>
                </div>

                <div class="form-group">
                    <input type="password" name="password" id="password" class="form-input" placeholder="Password" required minlength="6">
                </div>
                
                <div class="form-group">
                    <input type="text" name="ci" id="ci" class="form-input" placeholder="CI" required>
                </div>
                
                <div class="form-group">
                    <input type="email" name="email" id="email" class="form-input" placeholder="Email" required>
                </div>
                
                <div class="form-group">
                    <input type="tel" name="phone" id="phone" class="form-input" placeholder="Phone Number" required>
                </div>
                
                <button type="submit" id="submitBtn" class="signup-btn">
                    <span id="btnText">SIGN UP</span>
                </button>
            </form>
        </div>
        
        <div class="welcome-section">
            <h2>Welcome!</h2>
            <p>Enter your personal details and start your journey with us</p>
            <a href="loginLP.php" class="signin-btn">SIGN IN</a>
        </div>
    </div>

    <script>
        // Theme toggle functionality
        const themeToggle = document.getElementById('themeToggle');
        const body = document.body;
        const sunIcon = document.querySelector('.sun-icon');
        const moonIcon = document.querySelector('.moon-icon');

        // Get saved theme from memory (since we can't use localStorage in artifacts)
        let currentTheme = 'light';

        // Function to toggle theme
        function toggleTheme() {
            currentTheme = currentTheme === 'light' ? 'dark' : 'light';
            body.setAttribute('data-theme', currentTheme);
        }

        themeToggle.addEventListener('click', toggleTheme);

        // Form functionality
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const form = e.target;
            const data = {
                name: form.name.value,
                surname: form.surname.value,
                email: form.email.value,
                ci: form.ci.value,
                password: form.password.value,
                phone: form.phone.value
            };

            console.log(JSON.stringify(data));

            fetch('API_Usuarios.php/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                alert('Usuario registrado correctamente');
                location.reload();
            })
            .catch(error => {
                alert('Error al registrar usuario');
                console.error(error);
            });
        });
    </script>
</body>
</html>